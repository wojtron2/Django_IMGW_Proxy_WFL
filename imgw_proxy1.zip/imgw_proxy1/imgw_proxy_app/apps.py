from django.apps import AppConfig


class ImgwProxyAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'imgw_proxy_app'
